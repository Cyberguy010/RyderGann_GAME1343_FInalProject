using UnityEngine;

public class PlinkoDisk : MonoBehaviour
{
    public float lifetime = 15;

    // Start is called once the first execution of Update after the first MonoBehavior is created
    void Start()
    {
        Destroy(gameObject, lifetime);
    }

    // Update is called once per frame
    void Update()
    {

    }
}   
